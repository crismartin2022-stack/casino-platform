// Motor base compartido. Cada uno de los 5 motores hereda de aquí y solo implementa
// cómo se ANIMA su resultado (playResult). El resultado siempre viene del servidor.
import { Application, Container, Sprite, Texture, Text } from 'pixi.js';
import { gsap } from 'gsap';
import { GridView, wait } from './GridView.js';
import { Hud, h } from './Hud.js';
import { SoundManager } from './SoundManager.js';
import { isAnimated, isVideo, mediaEl, applyBackgroundMedia, loadFontFile } from './media.js';

const DESIGN = { landscape: { w: 1280, h: 720 }, portrait: { w: 720, h: 1280 } };
// Zonas en coordenadas de diseño: logo arriba, rodillos, espacio para la botonera (HTML) abajo.
const ZONES = {
  landscape: { logo: { y: 6, h: 118 }, grid: { x: 120, y: 132, w: 1040, h: 470 } },
  portrait: { logo: { y: 70, h: 170 }, grid: { x: 12, y: 250, w: 696, h: 700 } },
};

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`No se pudo cargar ${url}`));
    img.src = url;
  });
}

async function loadTexture(url, fallbackUrl) {
  try {
    return Texture.from(await loadImage(url));
  } catch (e) {
    if (!fallbackUrl) throw e;
    console.warn(e.message, '→ usando imagen provisional');
    return Texture.from(await loadImage(fallbackUrl));
  }
}

function loadFont(family) {
  if (!family || document.querySelector(`link[data-font="${family}"]`)) return Promise.resolve();
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.dataset.font = family;
  link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family).replace(/%20/g, '+')}:wght@400;700&display=swap`;
  document.head.appendChild(link);
  return Promise.race([document.fonts?.load(`16px "${family}"`) ?? Promise.resolve(), wait(1500)]).catch(() => {});
}

export class BaseEngine {
  constructor({ container, hudRoot, api, session, lobbyUrl }) {
    this.container = container;
    this.hudRoot = hudRoot;
    this.api = api;
    this.session = session;
    this.game = session.game;
    this.currency = session.currency;
    this.lobbyUrl = lobbyUrl;
    this.busy = false;
    this.symbols = new Map(this.game.symbols.map((s) => [s.id, s]));
  }

  // ---------------------------------------------------------------- Arranque
  async init(onProgress = () => {}) {
    const t = this.game.theme || {};
    this.orientation = this.detectOrientation();
    this.design = DESIGN[this.orientation];
    this.applyBackground();

    this.app = new Application();
    await this.app.init({
      resizeTo: this.container, backgroundAlpha: 0, antialias: true,
      resolution: Math.min(window.devicePixelRatio || 1, 2), autoDensity: true,
    });
    this.container.appendChild(this.app.canvas);
    this.world = new Container();
    this.app.stage.addChild(this.world);

    onProgress(0.1, 'Cargando tipografía…');
    // Tipografía propia subida (theme.fontUrl) o de Google Fonts (theme.font); la botonera puede tener otra (theme.hud.font/fontUrl)
    if (t.fontUrl) await loadFontFile(t.font, t.fontUrl); else await loadFont(t.font);
    if (t.hud?.fontUrl) await loadFontFile(t.hud.font, t.hud.fontUrl); else if (t.hud?.font) await loadFont(t.hud.font);

    onProgress(0.2, 'Cargando símbolos…');
    this.textures = new Map();
    let done = 0;
    const list = this.game.symbols;
    await Promise.all(list.map(async (s) => {
      const fallback = `/gen/symbol.svg?label=${encodeURIComponent(s.name || s.id)}&color=%23777777`;
      this.textures.set(s.id, await loadTexture(s.image || fallback, fallback));
      onProgress(0.2 + 0.6 * (++done / list.length), 'Cargando símbolos…');
    }));
    this.textures.set('__missing', await loadTexture('/gen/symbol.svg?label=%3F&color=%23555555'));
    const optional = async (url) => { if (!url) return null; try { return await loadTexture(url); } catch (e) { console.warn(e.message); return null; } };
    // Fondo de rodillos animado (GIF o video): va en una capa HTML detrás del lienzo, que es transparente.
    const reelsAnimated = isAnimated(t.reelsBackground);
    [this.logoTexture, this.cellTexture, this.reelsTexture, this.frameTexture] = await Promise.all(
      [t.logo, t.cellImage, reelsAnimated ? null : t.reelsBackground, t.frame].map(optional));
    if (reelsAnimated) {
      this.reelsMedia = mediaEl(t.reelsBackground, { fit: 'fill' });
      this.reelsMedia.className = 'reelsbg';
      this.container.prepend(this.reelsMedia);
    }

    onProgress(0.9, 'Preparando mesa…');
    this.sound = new SoundManager(this.game.sounds || {}, this.game.soundVolumes || {});
    this.buildScene();
    this.buildHud();
    const { balance } = await this.api.balance();
    this.hud.setBalance(balance);
    window.addEventListener('resize', () => this.onResize());
    this.fit();
    const unlock = () => { this.sound.unlock(); this.sound.playMusic('music'); };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    onProgress(1, 'Listo');
  }

  detectOrientation() {
    const w = this.container.clientWidth || window.innerWidth, h = this.container.clientHeight || window.innerHeight;
    return h > w * 1.1 ? 'portrait' : 'landscape';
  }

  /** Fondo de pantalla completa por CSS: imagen de PC (theme.background) y de celular (theme.backgroundMobile). */
  applyBackground() {
    const t = this.game.theme || {};
    const el = document.getElementById?.('bg');
    if (!el) return;
    applyBackgroundMedia(t, this.orientation);
    const url = (u) => (u ? `url("${String(u).replace(/"/g, '%22')}")` : null);
    // Los videos no van por CSS (applyBackgroundMedia los pone como <video>)
    if (url(t.background) && !isVideo(t.background)) el.style.setProperty('--bg-desktop', url(t.background));
    if (url(t.backgroundMobile) && !isVideo(t.backgroundMobile)) el.style.setProperty('--bg-mobile', url(t.backgroundMobile));
    if (t.backgroundColor) el.style.setProperty('--bg-color', t.backgroundColor);
  }

  onResize() {
    const o = this.detectOrientation();
    if (o !== this.orientation) {
      // Al girar el teléfono se rearma la escena con el diseño de la nueva orientación.
      if (this.busy) { this.pendingRelayout = true; return; }
      this.relayout(o);
    }
    this.fit();
  }

  relayout(orientation) {
    this.orientation = orientation;
    applyBackgroundMedia(this.game.theme || {}, orientation);
    this.design = DESIGN[orientation];
    for (const ch of this.world.removeChildren()) ch.destroy({ children: true });
    this.buildScene();
    this.fit();
  }

  /** Área de la cuadrícula en coordenadas de diseño. */
  gridArea() {
    const box = ZONES[this.orientation].grid;
    const rows = this.gridRows();
    if (Array.isArray(rows)) return box; // Megaways: altura variable, ocupa todo el espacio
    // Celdas casi cuadradas para cualquier cantidad de rodillos y filas, centradas en el espacio disponible.
    const cols = this.gridCols();
    const cell = Math.min(box.w / cols, box.h / rows, 210);
    const w = cell * cols, h = cell * rows;
    return { x: box.x + (box.w - w) / 2, y: box.y + (box.h - h) / 2, w, h };
  }

  /** Texto de reglas con los números reales del juego (rodillos, filas, líneas). */
  rulesText() { return ''; }

  gridLabel() {
    const g = this.game.grid;
    return `${g.reels} rodillos × ${g.rows ?? `${g.rowsMin}–${g.rowsMax}`} filas`;
  }

  gridRows() { return this.game.grid.rows; }
  gridCols() { return this.game.grid.reels; }

  fillerIds() {
    return this.game.symbols.filter((s) => s.type === 'regular' || !s.type).map((s) => s.id);
  }

  buildScene() {
    const w = this.design.w, hgt = this.design.h;
    const t = this.game.theme || {};
    const a = this.gridArea();
    this.gridRect = a;
    this.grid = new GridView({
      textures: this.textures, fillerIds: this.fillerIds(), cols: this.gridCols(), rows: this.gridRows(),
      width: a.w, height: a.h, ticker: this.app.ticker, palette: t.palette,
      look: {
        gap: t.cellGap ?? 6, symbolScale: t.symbolScale ?? 0.92,
        cellColor: t.cellColor, cellAlpha: t.cellAlpha, cellRadius: t.cellRadius,
        cellBorder: t.cellBorder === 'none' ? null : t.cellBorder, frameColor: t.frameColor,
        cellTexture: this.cellTexture, reelsTexture: this.reelsTexture, frameTexture: this.frameTexture,
        frameLayer: t.frameLayer, frameScale: t.frameScale, frameCut: t.frameCut,
      },
    });
    this.grid.position.set(a.x, a.y);
    this.world.addChild(this.grid);
    this.grid.setGrid(this.randomGrid());

    // Logo (imagen) o, si no hay, el título con la tipografía del juego.
    const z = ZONES[this.orientation].logo;
    const logoBottom = Math.min(z.y + z.h, a.y - 10);
    if (this.logoTexture) {
      const logo = new Sprite(this.logoTexture);
      logo.anchor.set(0.5, 1);
      const k = Math.min((this.orientation === 'portrait' ? 640 : 560) / logo.texture.width, (logoBottom - z.y) / logo.texture.height);
      logo.scale.set(k);
      logo.position.set(w / 2, logoBottom);
      this.world.addChild(logo);
    } else {
      const title = new Text({
        text: t.title || this.game.name,
        style: {
          fontFamily: t.font || 'Arial', fontSize: this.orientation === 'portrait' ? 64 : 58, fontWeight: '700',
          fill: t.palette?.accent || '#ffd460', stroke: { color: '#000000', width: 7 },
          dropShadow: { color: '#000000', blur: 10, distance: 4, alpha: 0.7 }, align: 'center',
          wordWrap: true, wordWrapWidth: w - 60,
        },
      });
      title.anchor.set(0.5, 1);
      const k = Math.min(1, (logoBottom - z.y) / Math.max(1, title.height));
      title.scale.set(k);
      title.position.set(w / 2, logoBottom);
      this.world.addChild(title);
    }
    // Frase bajo los rodillos (theme.tagline), en celular entre rodillos y botonera
    if (t.tagline && this.orientation === 'portrait') {
      const tag = new Text({ text: t.tagline, style: { fontFamily: t.font || 'Arial', fontSize: 30, fill: t.palette?.accent || '#ffd460', stroke: { color: '#000000', width: 5 } } });
      tag.anchor.set(0.5, 0);
      tag.position.set(w / 2, a.y + a.h + 16);
      this.world.addChild(tag);
      this.taglineH = 56;
    } else this.taglineH = 0;
    // Texto de premio sobre la cuadrícula
    this.winText = new Text({
      text: '',
      style: {
        fontFamily: this.game.theme?.font || 'Arial', fontSize: 64, fill: this.game.theme?.palette?.accent || '#ffd460',
        stroke: { color: '#000000', width: 8 }, dropShadow: { color: '#000000', blur: 8, distance: 4, alpha: 0.6 },
      },
    });
    this.winText.anchor.set(0.5);
    this.winText.position.set(a.x + a.w / 2, a.y + a.h / 2);
    this.onSceneBuilt?.();
    this.winText.alpha = 0;
    this.world.addChild(this.winText);
  }

  randomGrid() {
    const ids = this.fillerIds();
    const rows = this.gridRows();
    return Array.from({ length: this.gridCols() }, (_, c) =>
      Array.from({ length: Array.isArray(rows) ? rows[c] : rows }, () => ids[Math.floor(Math.random() * ids.length)]));
  }

  buildHud() {
    this.hud = new Hud(this.hudRoot, {
      game: this.game, currency: this.currency, lobbyUrl: this.lobbyUrl, preview: this.session.source === 'draft',
      onSpin: () => this.spin('base'),
      onBuy: this.supportsBuy() ? () => this.buyBonus() : null,
      onInfo: () => this.showInfo(),
      onToggleSound: () => this.sound.toggleMute(),
      onHistory: () => this.api.history(20),
      // Solo en la vista previa del borrador: el próximo giro trae el bonus
      onForce: this.session.source === 'draft' ? () => this.spin('base', { force: true }) : null,
    });
    this.hud.onTurbo = (v) => { this.grid.turbo = v; };
  }

  /** Gancho para limpiar capas propias del motor (etiquetas, colosales…) antes de girar. */
  onSpinStart() {}

  fit() {
    const W = this.container.clientWidth || window.innerWidth, H = this.container.clientHeight || window.innerHeight;
    // Interfaces completas: barra superior, dock inferior y panel lateral ocupan píxeles fijos; los rodillos van en el resto.
    const R = this.hud?.reserve?.(this.orientation);
    if (R) {
      const usedH = R.full ? this.design.h : this.gridRect.y + this.gridRect.h + (this.taglineH || 0) + 12;
      const availW = Math.max(200, W - 2 * R.side), availH = Math.max(200, H - R.top - R.bottom);
      const k = Math.min(availW / this.design.w, availH / usedH);
      this.world.scale.set(k);
      const ox = (W - this.design.w * k) / 2;
      const oy = R.top + Math.max(0, (availH - usedH * k) / 2);
      this.world.position.set(ox, oy);
      const r = this.gridRect;
      this.hud.setLayout({ x: ox + r.x * k, y: oy + r.y * k, w: r.w * k, h: (r.h + (this.taglineH || 0)) * k }, this.orientation, k);
      this.hud.setWorld?.({ ox, oy, k, w: this.design.w, h: this.design.h, gridBottom: r.y + r.h + (this.taglineH || 0) });
      this.placeReelsMedia(ox, oy, k);
      this.hud.renderBet();
      return;
    }
    // Reserva espacio para la botonera HTML debajo de los rodillos (más si la interfaz está agrandada).
    const barSpace = (this.orientation === 'portrait' ? 250 : 110) * (this.hud?.uiScale || 1);
    const usedH = this.gridRect.y + this.gridRect.h + barSpace + (this.taglineH || 0);
    const k = Math.min(W / this.design.w, H / usedH);
    this.world.scale.set(k);
    const ox = (W - this.design.w * k) / 2;
    const oy = this.orientation === 'portrait' ? Math.max(0, (H - usedH * k) / 2) : Math.max(0, (H - usedH * k) / 2);
    this.world.position.set(ox, oy);
    const r = this.gridRect;
    this.hud?.setLayout({ x: ox + r.x * k, y: oy + r.y * k, w: r.w * k, h: (r.h + (this.taglineH || 0)) * k }, this.orientation, k);
    this.hud?.setWorld?.({ ox, oy, k, w: this.design.w, h: this.design.h, gridBottom: r.y + r.h + (this.taglineH || 0) });
    this.placeReelsMedia(ox, oy, k);
  }

  /** Coloca el fondo de rodillos animado exactamente detrás de la cuadrícula (mismo margen que la imagen fija). */
  placeReelsMedia(ox, oy, k) {
    if (!this.reelsMedia) return;
    const r = this.gridRect;
    Object.assign(this.reelsMedia.style, { left: `${ox + (r.x - 10) * k}px`, top: `${oy + (r.y - 10) * k}px`, width: `${(r.w + 20) * k}px`, height: `${(r.h + 20) * k}px` });
  }

  // ---------------------------------------------------------------- Ciclo de juego
  async spin(mode = 'base', { force = false } = {}) {
    if (this.busy) return;
    const bet = this.hud.bet;
    const cost = Math.round(bet * this.costFor(mode));
    if (this.hud.balance < cost) { this.hud.error('Saldo insuficiente para esta apuesta.'); return; }
    this.busy = true;
    this.hud.lock(true);
    this.hud.setWin(0);
    this.roundWin = 0;
    this.hud.setBalance(this.hud.balance - cost); // visual: el servidor confirma el saldo real
    this.sound.unlock();
    this.sound.play('spin');
    this.grid.undim();
    this.onSpinStart();
    this.grid.startSpin();
    let round;
    try {
      [round] = await Promise.all([this.api.spin(bet, mode, { force }), wait(this.hud.turbo ? 150 : 380)]);
    } catch (e) {
      await this.grid.stop(this.randomGrid());
      this.hud.setBalance(this.hud.balance + cost);
      this.api.balance().then((b) => this.hud.setBalance(b.balance)).catch(() => {});
      this.hud.error(e.message || 'Error de conexión');
      this.busy = false;
      this.hud.lock(false);
      return;
    }
    try {
      this.currentBet = bet;
      await this.playResult(round.result, round);
    } catch (e) {
      console.error('Error animando la ronda', e); // el dinero ya está resuelto en el servidor
    }
    if (round.win > 0) this.hud.countWin(round.win, 400); else this.hud.setWin(0);
    if (round.win > 0) await this.presentTotal(round.win, bet);
    this.hud.setBalance(round.balance);
    // Aviso al sitio del operador cuando el juego va embebido en un iframe (client-sdk).
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: 'casino:round', gameId: this.game.id, roundId: round.roundId, bet: round.bet, cost: round.cost, win: round.win, balance: round.balance }, '*');
    }
    if (round.creditPending) this.hud.setStatus('Premio en proceso de acreditación por el operador…');
    this.busy = false;
    if (this.pendingRelayout) { this.pendingRelayout = false; this.relayout(this.detectOrientation()); }
    this.hud.lock(false);
    if (this.hud.autoLeft > 0 && !(round.result.freeSpins || round.result.holdAndWin)) {
      if (this.hud.consumeAuto()) setTimeout(() => this.spin('base'), 220);
    } else if (round.result.freeSpins || round.result.holdAndWin) {
      this.hud.stopAuto();
    }
  }

  /** Implementado por cada motor. Debe dejar la cuadrícula en su estado final. */
  async playResult() { throw new Error('playResult no implementado'); }

  money(mult, bet = this.currentBet) { return Math.round(mult * bet); }

  /** Detiene los rodillos. Pone "anticipación" si ya hay 2 scatters antes de los últimos rodillos. */
  async stopReels(grid, { scatterId } = {}) {
    let seen = 0;
    const anticipation = [];
    if (scatterId) {
      grid.forEach((col, c) => {
        if (seen >= 2) anticipation.push(c);
        seen += col.filter((id) => id === scatterId).length;
      });
    }
    await this.grid.stop(grid, { anticipation, onReelStop: () => this.sound.play('reelStop') });
  }

  /** Muestra ganancias de un paso: resalta, suma y muestra el importe. */
  async presentWins(wins, stepWinMult) {
    if (!wins?.length) return;
    this.sound.play('win');
    const positions = wins.flatMap((w) => w.positions);
    const lines = wins.filter((w) => w.line != null).map((w) => w.positions);
    const cents = this.money(stepWinMult);
    this.flashWinText(cents);
    this.roundWin = (this.roundWin || 0) + cents;
    this.hud.countWin(this.roundWin);
    await this.grid.highlight(positions, { lines });
    this.grid.undim();
  }

  flashWinText(cents) {
    // Cuenta hacia arriba el importe sobre los rodillos
    const obj = { v: 0 };
    gsap.to(obj, { v: cents, duration: this.hud.turbo ? 0.25 : 0.45, ease: 'power2.out', onUpdate: () => { this.winText.text = this.hud.fmt(Math.round(obj.v)); } });
    this.winText.text = this.hud.fmt(0);
    gsap.killTweensOf(this.winText);
    gsap.killTweensOf(this.winText.scale);
    this.winText.alpha = 1;
    this.winText.scale.set(0.4);
    gsap.to(this.winText.scale, { x: 1, y: 1, duration: 0.35, ease: 'back.out(2)' });
    gsap.to(this.winText, { alpha: 0, duration: 0.4, delay: this.hud.turbo ? 0.5 : 1.1 });
  }

  async presentTotal(cents, bet) {
    const x = cents / bet;
    if (x >= 50) {
      this.sound.play('bigWin');
      await this.hud.showBanner(`<small>¡MEGA PREMIO!</small><b>${this.hud.fmt(cents)}</b>`, { kind: 'big', ms: 3200 });
    } else if (x >= 15) {
      this.sound.play('bigWin');
      await this.hud.showBanner(`<small>GRAN PREMIO</small><b>${this.hud.fmt(cents)}</b>`, { kind: 'big', ms: 2400 });
    } else if (x >= 1) {
      await this.hud.showBanner(`<b>${this.hud.fmt(cents)}</b>`, { kind: 'win', ms: 900 });
    }
  }

  async featureIntro(title, sub = '') {
    this.sound.play('feature');
    this.sound.playMusic('featureMusic');
    await this.hud.showBanner(`<small>${sub}</small><b>${title}</b>`, { kind: 'feature', ms: 2000 });
  }

  async featureOutro(totalMult) {
    await this.hud.showBanner(`<small>TOTAL DEL BONUS</small><b>${this.hud.fmt(this.money(totalMult))}</b>`, { kind: 'feature', ms: 2200 });
    this.sound.playMusic('music');
  }

  /** Precio (en múltiplos de la apuesta) de cada modo de juego. */
  costFor(mode) {
    const R = this.game.rules || {};
    if (mode === 'base') return 1;
    if (mode === 'buy') return R.buyCost || 1;
    const key = { 'buy-sticky': 'sticky', 'buy-wheel': 'wheel', 'buy-pick': 'pick' }[mode];
    return R.bonusMenu?.[key]?.cost || 1;
  }

  /** Opciones de compra disponibles: [{ mode, name, cost }]. */
  buyOptions() {
    const R = this.game.rules || {};
    const out = [];
    if (R.buyCost) out.push({ mode: 'buy', name: 'Giros gratis', cost: R.buyCost });
    const names = { sticky: 'Giros gratis con wilds fijos', wheel: 'Ruleta de la fortuna', pick: 'Elige un premio' };
    for (const [key, mode] of [['sticky', 'buy-sticky'], ['wheel', 'buy-wheel'], ['pick', 'buy-pick']]) {
      const o = R.bonusMenu?.[key];
      if (o) out.push({ mode, name: o.name || names[key], cost: o.cost });
    }
    return out;
  }

  supportsBuy() { return this.buyOptions().length > 0; }

  async buyBonus() {
    if (this.busy) return;
    const opts = this.buyOptions();
    if (opts.length === 1) {
      const price = this.hud.bet * opts[0].cost;
      const ok = await this.hud.confirm('Comprar bonus', `¿Comprar ${opts[0].name.toLowerCase()} por ${this.hud.fmt(price)}?`, `Comprar por ${this.hud.fmt(price)}`);
      if (ok) this.spin(opts[0].mode);
      return;
    }
    const mode = await this.hud.choose('Comprar bonus', opts.map((o) => ({ value: o.mode, label: o.name, sub: this.hud.fmt(this.hud.bet * o.cost) })));
    if (mode) this.spin(mode);
  }

  // ---------------------------------------------------------------- Reglas y pagos (obligatorio en mercados regulados)
  payUnit() { return 1; }

  /** Cómo se muestra cada cantidad de la tabla de pagos (los motores de grupos la cambian). */
  payLabel(n) { return `${n}`; }

  showInfo() {
    const bet = this.hud.bet;
    const unit = this.payUnit();
    const rows = this.game.symbols.map((s) => {
      const keys = Object.keys(s.pays || {});
      const pays = Object.entries(s.pays || {}).sort((a, b) => b[0] - a[0])
        .map(([n, p]) => h('div', {}, `${this.payLabel(n, keys)}× `, h('b', {}, this.hud.fmt(Math.round(p * unit * bet)))));
      // Pagos de scatter en cualquier posición (múltiplos de la apuesta total)
      const sp = Object.entries(s.scatterPays || {}).sort((a, b) => b[0] - a[0])
        .map(([n, p]) => h('div', {}, `${n}× `, h('b', {}, this.hud.fmt(Math.round(p * bet)))));
      const kind = {
        wild: 'Sustituye a los símbolos normales', scatter: 'Activa los giros gratis', coin: 'Activa el bonus Hold & Win',
        wildscatter: 'Comodín y scatter: activa los giros gratis', multiplier: 'Multiplica el premio del giro', mystery: 'Se revela como un símbolo al azar',
      }[s.type] || null;
      return h('div', { class: 'pay' }, h('img', { src: s.image, alt: s.name }), h('div', {}, h('strong', {}, s.name), kind ? h('div', {}, kind) : null, ...pays, ...sp));
    });
    const rtp = this.game.math?.rtp ? `${(this.game.math.rtp * 100).toFixed(2)} %` : '—';
    this.hud.openModal(h('div', { class: 'info' },
      h('h2', {}, this.game.theme?.title || this.game.name),
      h('p', {}, this.rulesText()),
      h('p', {}, `Premios de la tabla calculados para la apuesta actual (${this.hud.fmt(bet)}). Premio máximo: ${this.game.rules?.maxWin ?? '—'}× la apuesta.`),
      h('div', { class: 'paytable' }, rows),
      h('p', { class: 'fine' }, `RTP teórico: ${rtp}. Versión ${this.game.version ?? 'borrador'}. Los resultados se determinan en el servidor con un generador de números aleatorios certificable; el mal funcionamiento anula pagos y jugadas. Juega con responsabilidad.`)));
  }
}

export { wait, h, gsap };
