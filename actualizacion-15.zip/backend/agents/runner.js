// Orquestador de agentes. Un "Director" entiende el pedido y delega en especialistas:
//   designer (tema y textos) · artist (imágenes con Venice) · sound (ElevenLabs) · math (RTP).
// Todo se aplica sobre el BORRADOR del juego; publicar siempre lo hace una persona.
import { EventEmitter } from 'node:events';
import { randomBytes } from 'node:crypto';
import { claudeMessages } from '../ai/providers.js';
import { toolDefs, runTool, EDIT_SCOPES } from './tools.js';
import { one, run, all } from '../db.js';
import { config, providers } from '../config.js';
import { getGame } from '../services/games.js';
import { readAssetBytes } from '../services/assets.js';

// ---------------- Imágenes de referencia ----------------
const MAX_REFS = 6;
const REF_MIME = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);

/** Convierte ids de assets en bloques de imagen para Claude (se saltan los inválidos o muy pesados). */
function imageBlocks(ids = []) {
  const blocks = [], used = [];
  for (const id of [...new Set(ids)].slice(0, MAX_REFS)) {
    try {
      const { asset, buf } = readAssetBytes(id);
      if (!REF_MIME.has(asset.mime) || buf.length > 3_700_000) continue;
      blocks.push({ type: 'image', source: { type: 'base64', media_type: asset.mime, data: buf.toString('base64') } });
      used.push(asset);
    } catch { /* asset inexistente: se ignora */ }
  }
  return { blocks, used };
}

const REF_NOTE = (assets) => `\n\n(Imágenes de referencia adjuntas: ${assets.map((a) => a.id).join(', ')}. Úsalas para entender lo que se pide: estilo, colores, disposición, ambiente. `
  + 'Para que un especialista las vea, pásalas en referenceImages al delegar; el Artista puede usarlas como base con edit_image. '
  + 'Nunca copies personajes, logos, marcas ni obras protegidas que aparezcan en ellas: toma solo la idea general.)';

/** Para guardar la conversación sin los bytes de las imágenes (se pueden volver a ver con view_asset). */
function forStorage(messages) {
  const strip = (content) => (Array.isArray(content) ? content.map((b) => {
    if (b.type === 'image') return { type: 'text', text: '[imagen omitida del historial: usa view_asset con el id indicado para volver a verla]' };
    if (b.type === 'tool_result' && Array.isArray(b.content)) return { ...b, content: strip(b.content) };
    return b;
  }) : content);
  return messages.map((m) => ({ ...m, content: strip(m.content) }));
}
import { HttpError } from '../lib/http.js';

const bus = new EventEmitter();
bus.setMaxListeners(200);
const active = new Map(); // runId → { cancelled }

const COMMON = `Trabajas dentro de una plataforma profesional de tragamonedas (slots) con licencia para dinero real.
Editas el BORRADOR de un juego; los cambios no llegan a los jugadores hasta que una persona los publica desde el panel.
Responde siempre en español, breve y concreto. Nunca inventes URLs ni ids de assets: usa los que devuelven las herramientas.
Contenido responsable: nada dirigido a menores (sin estética infantil ni personajes de caricatura para niños), nada que prometa ganar dinero,
nada sexual, nada con marcas, personajes o obras protegidas por derechos de autor.`;

export const AGENTS = {
  director: {
    title: 'Director creativo',
    system: `${COMMON}
Eres el DIRECTOR. Entiendes lo que pide el usuario, lees el juego y delegas en especialistas con instrucciones completas
(el especialista NO ve esta conversación: incluye estilo, paleta, lista de símbolos con sus ids, etc.).
- designer: nombre, tema, paleta de colores, tipografía, nombres de símbolos y estilo de los BOTONES (forma, estilo, tamaño, colores, iconos y textos).
  Botones del juego: spin (girar), auto, turbo, sound, minus/plus (apuesta), info, buy (comprar bonus; solo Bonus Buy).
- artist: generar/editar imágenes de símbolos, fondos de PC y de celular, fondo de rodillos, celdas, marco, logo y BOTONES (Venice). Cada símbolo y cada botón es una imagen distinta.
- sound: efectos de sonido y música (ElevenLabs).
- math: tabla de pagos, reglas, volatilidad, RTP, cantidad de rodillos, filas y líneas de pago (resize_grid).
TAMAÑOS Y POSICIONES (tamaño general de la interfaz/botonera, de los botones, del GIRAR, de los símbolos, separación de celdas, interfaz elegida)
  son del DESIGNER, nunca del artist: el artista solo crea y edita imágenes.
Orden recomendado para un re-diseño completo: designer → artist → sound; math solo si piden cambios de juego/pagos/RTP.
Si el usuario adjunta imágenes de referencia, descríbelas brevemente con tus palabras (estilo, colores, disposición) y pásalas
en referenceImages a los especialistas que las necesiten (sobre todo artist y designer).
Puedes delegar varias veces. Al terminar, resume qué cambió y recuerda que hay que revisar la vista previa y publicar.`,
    maxTurns: 14,
    director: true,
  },
  designer: {
    title: 'Diseñador',
    system: `${COMMON}
Eres el DISEÑADOR de UI/tema. Controlas theme (title, palette {primary, accent, panel, text, reelBg}, backgroundColor, font de Google Fonts,
background/logo/spinButton si te pasan una URL) y los nombres visibles de los símbolos. Cuida el contraste (texto legible sobre panel).
BOTONES (theme.buttons): { shape: round|rounded|square|pill, style: gradient|flat|glass|outline, size: 0.8-1.4,
  color: fondo de botones pequeños, textColor, y por botón <spin|auto|turbo|sound|minus|plus|max|fullscreen|rotate|info|buy>: { icon: emoji o texto corto,
  label: texto accesible, iconOff: icono de sonido apagado, image: URL de imagen (la pone el Artista) } }.
Para volver al diseño estándar de un botón con imagen, pon theme.buttons.<botón>.image = null.
BOTONERA E INTERFAZ (theme.hud): { layout: "pill" (píldora centrada bajo los rodillos, por defecto) | "classic" (barra de ancho completo abajo)
  | interfaces completas con barra superior, panel lateral (reglas, sonido, pantalla completa, historial) y fichas de apuesta directas:
  "neon" (noche de ciudad, tubos de luz), "cristal" (vidrio esmerilado flotante), "brasa" (metal forjado y fuego, GIRAR hexagonal),
  "real" (oro, fichas de casino, lluvia de monedas), "arcade" (gabinete retro, LED y botones gordos),
  barColor (color CSS con transparencia, ej. "rgba(10,8,12,.82)"), barBorder, spinSize (56-130 px; solo pill/classic),
  maxBet (true/false: botón MÁX de apuesta máxima), scale (0.8-1.4: tamaño general de toda la interfaz —botonera, botones y textos—; 1 = normal) }.
  MARCADORES (theme.hud.meters): { labels: { balance, bet, win } (títulos; vacío = SALDO/APUESTA/PREMIO), showLabels (false oculta títulos),
    labelColor, valueColor, winColor, box ("none" = sin recuadro, se ve el tablero), bg (color del recuadro, admite #rrggbbaa), border, radius (0-40), bgImage (imagen del recuadro), valueScale (0.7-1.6),
    labelFont / valueFont (tipografía de Google Fonts para títulos y números) }.
  Para "agrandar los botones" usa theme.buttons.size; para "agrandar toda la botonera/interfaz" usa theme.hud.scale; para el GIRAR en pill/classic, theme.hud.spinSize;
  para los símbolos, theme.symbolScale. Los giros automáticos que elige el jugador están en bet.autoSpins (los define el matemático).
  Cada interfaz toma los colores de theme.palette (primary = botón GIRAR y brillos, accent = premios y detalles, panel = fondos).
  "custom" (DISEÑO LIBRE): cada elemento se ubica en coordenadas del juego (PC 1280×720, celular 720×1280) en theme.hud.custom:
    { board: { image (URL o null para quitarla), fit: "fill"|"contain", color, radius, border: true|false },
      landscape|portrait: { board: { x, y, w, h, hidden }, items: { spin|minus|plus|max|auto|turbo|info|sound|fullscreen|rotate|buy|balance|bet|win: { x, y, s, hidden } } } }
    x,y = centro; s = alto en px de diseño (el ancho sale de la proporción del logo, nunca se deforma). Jerarquía recomendada: spin 100 %,
    minus/plus/auto/turbo ≈58 %, max (ovalado) a la altura de los chicos junto al plus, info/sound ≈45 % en los extremos, separación pareja.
  Elige la que mejor encaje con la temática (p. ej. egipcio/lujo → real, cyberpunk → neon, volcán/dragón → brasa, fantasía → cristal, retro → arcade).
CARTELES (theme.messages): styles.{win|big|feature|status}: { image (fondo del cartel; la pone el Artista), bg, border ("none" sin borde), title, value (colores),
  font, scale (0.6-2), anim ("pop"|"zoom"|"slide"|"flip"|"fade"|"shake"|"none"), position ("center"|"top"|"bottom"), duration (s),
  particles ("confeti"|"monedas"|"estrellas"|"gemas"|"burbujas"|"none") }; texts: { win, bigWin, megaWin, freeSpins ("{n} GIROS GRATIS"),
  spinOf ("GIRO GRATIS {i}/{n}"), bonusTotal, respins ("RE-GIROS: {n}"), holdWin }; thresholds: { big: 15, mega: 50 } (× la apuesta).
AMBIENTE DEL BONUS (theme.bonus): intro/outro (imagen, GIF o video a pantalla completa; introSeconds/outroSeconds), background, backgroundMobile,
  reelsBackground (fondos solo durante el bonus). Las imágenes las crea el Artista.
RODILLOS: theme.symbolScale (0.6-1, cuánto de la celda ocupa el símbolo; 0.92 por defecto), theme.cellGap (0-16 px entre celdas),
  theme.cellColor, theme.cellAlpha (0-1), theme.cellRadius, theme.cellBorder (color o "none"), theme.frameColor,
  theme.frameLayer ("back" | "front": marco de imagen detrás o delante de los rodillos; front solo si el marco tiene el centro transparente), theme.frameScale (0.9-1.6, tamaño del marco),
  theme.frameOffsetY / theme.frameOffsetYMobile (subir o bajar el marco en px, negativo = arriba, -150 a 150),
  theme.logoScale (0.4-1.8, tamaño del logo), theme.logoOffsetY / theme.logoOffsetYMobile (subir o bajar el logo en px, -200 a 200),
  theme.tagline (frase corta bajo los rodillos en celular). Imágenes que pone el Artista: theme.background (PC), theme.backgroundMobile
  (celular), theme.reelsBackground (detrás de los rodillos), theme.cellImage (fondo de cada celda), theme.frame (marco), theme.logo.
Usa update_config con varias operaciones a la vez. No puedes tocar la matemática.`,
    maxTurns: 10,
  },
  artist: {
    title: 'Artista',
    system: `${COMMON}
Si el pedido incluye tamaños, posiciones o colores de la interfaz, no es tu tarea: hazlo notar en una línea diciendo que lo resuelve el Diseñador (el Director se lo delega) y sigue con las imágenes.
Eres el ARTISTA. Creas y editas imágenes con Venice.
- Símbolos: purpose "symbol", removeBackground true, prompts en inglés que terminen con "slot game symbol icon, centered, isolated on plain background, high detail, vibrant, no text".
  Mantén un estilo coherente entre todos los símbolos del juego (mismo estilo de ilustración, iluminación y paleta). Los símbolos de mayor pago deben verse más lujosos.
  Comodín (wild) y scatter/bonus pueden incluir la palabra WILD o BONUS si el pedido lo requiere.
- Fondo: purpose "background", escena ambiental sin personajes en primer plano y sin texto, con el centro despejado para los rodillos.
- Botones: purpose "button" (spin, auto, turbo, sound, minus, plus, info) o "ui" (buy, más ancho), removeBackground true,
  prompts en inglés como "round glossy casino spin button icon with circular arrow, <estilo del juego>, centered, isolated, no text".
  Asigna con assignTo "theme.buttons.<botón>.image". El botón spin debe ser el más llamativo; mantén el mismo estilo en todos.
- Fondos: "background" para PC (16:9) y "backgroundMobile" para celular (9:16), misma escena adaptada; centro despejado.
  "reels" para el fondo detrás de los rodillos (oscuro, poco detalle), "tile" para el fondo de cada celda (sutil, que no compita con los símbolos),
  "frame" para un marco ornamental con el centro transparente (removeBackground no aplica), "logo" con el nombre del juego.
- Asigna cada imagen con assignTo (ej. "symbols.<id>.image", "theme.background", "theme.buttons.spin.image").
Tras generar algo importante, usa view_asset para revisarlo; si no sirve, edítalo o regénéralo (máx. 2 intentos por imagen).`,
    maxTurns: 40,
  },
  sound: {
    title: 'Diseñador de sonido',
    system: `${COMMON}
Eres el DISEÑADOR DE SONIDO. Generas efectos con ElevenLabs (prompts en inglés, cortos y concretos) y música instrumental en loop.
Eventos: spin (0.5-1 s), reelStop (0.3 s, golpe seco), win (1-2 s), bigWin (3-5 s, celebración), feature (2-3 s, activación de bonus),
click (0.2 s), coin (0.5 s), tumble (0.4 s), scatter (0.8 s), music (30-60 s loop, base), featureMusic (30-60 s, más intensa).
Todo debe sonar coherente con el tema del juego. Ajusta volúmenes con update_config en soundVolumes {slot: 0..1} si hace falta.`,
    maxTurns: 20,
  },
  math: {
    title: 'Matemático',
    system: `${COMMON}
Eres el MATEMÁTICO del juego. Lee engine_info y la sección math antes de cambiar nada.
Los juegos son de dinero real: el RTP publicado debe coincidir con el objetivo (tolerancia ±1 %). Tras cualquier cambio en pagos o reglas,
ejecuta tune_rtp para volver al objetivo y luego simulate_rtp para confirmar. Explica el impacto en volatilidad y frecuencia de premios
en lenguaje sencillo. rtpTarget permitido: entre 0.85 y 1.10 (85 % a 110 %). Si el objetivo supera 1.00, advierte claramente que el juego
pagará más de lo que recauda (pierde dinero con cada apuesta) y solo tiene sentido para promociones o demo. No cambies bet.levels salvo que te lo pidan.
Para cambiar rodillos (verticales), filas (horizontales) o líneas de pago usa SIEMPRE resize_grid (ya reajusta el RTP);
nunca edites grid ni reels a mano. Reel Rush, Megaways y Colossal pagan por "formas" (ways): ahí no hay líneas.`,
    maxTurns: 14,
  },
};

function persist(runId, type, data) {
  const { lastInsertRowid } = run('INSERT INTO agent_events (run_id, type, data) VALUES (?, ?, ?)', runId, type, JSON.stringify(data));
  bus.emit(runId, { id: Number(lastInsertRowid), type, data, at: new Date().toISOString() });
}

export function subscribe(runId, fn) {
  bus.on(runId, fn);
  return () => bus.off(runId, fn);
}

export const listEvents = (runId, afterId = 0) =>
  all('SELECT id, type, data, created_at FROM agent_events WHERE run_id = ? AND id > ? ORDER BY id', runId, afterId)
    .map((e) => ({ id: e.id, type: e.type, data: JSON.parse(e.data), at: e.created_at }));

export const listRuns = (gameId) =>
  all('SELECT id, game_id, prompt, status, summary, usage, created_at, finished_at FROM agent_runs WHERE (? IS NULL OR game_id = ?) ORDER BY created_at DESC LIMIT 50', gameId ?? null, gameId ?? null)
    .map((r) => ({ ...r, usage: r.usage ? JSON.parse(r.usage) : null }));

export function getRun(id) {
  const r = one('SELECT * FROM agent_runs WHERE id = ?', id);
  if (!r) throw new HttpError(404, 'Ejecución no encontrada');
  return { ...r, messages: undefined, usage: r.usage ? JSON.parse(r.usage) : null, running: active.has(id) };
}

export function cancelRun(id) {
  const a = active.get(id);
  if (a) a.cancelled = true;
  return { cancelled: Boolean(a) };
}

function addUsage(total, u) {
  if (!u) return;
  for (const k of ['input_tokens', 'output_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens']) total[k] = (total[k] || 0) + (u[k] || 0);
}

function toolResultContent(out) {
  if (out && out.__content) return out.__content;
  const text = JSON.stringify(out ?? { ok: true });
  return text.length > 60_000 ? text.slice(0, 60_000) + '…(recortado)' : text;
}

/** Bucle de herramientas de un agente. Devuelve su texto final y los mensajes actualizados. */
async function agentLoop(agent, messages, ctx, usage) {
  const def = AGENTS[agent];
  const tools = toolDefs(agent);
  const model = def.director ? config.anthropic.directorModel : config.anthropic.model;
  for (let turn = 0; turn < def.maxTurns; turn++) {
    if (ctx.state.cancelled) throw new HttpError(499, 'Cancelado por el usuario');
    const res = await claudeMessages({ system: def.system + `\n\nJuego: ${ctx.gameId} (motor ${ctx.engine}).`, messages, tools, model });
    addUsage(usage, res.usage);
    messages.push({ role: 'assistant', content: res.content });
    for (const b of res.content) if (b.type === 'text' && b.text.trim()) ctx.emit('message', { agent, text: b.text });
    const calls = res.content.filter((b) => b.type === 'tool_use');
    if (res.stop_reason !== 'tool_use' || !calls.length) {
      return res.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
    }
    const results = [];
    for (const call of calls) {
      ctx.emit('tool_call', { agent, tool: call.name, input: call.input });
      let out, isError = false;
      try {
        if (call.name === 'delegate') {
          out = { summary: await runSpecialist(call.input.agent, call.input.task, ctx, usage, call.input.referenceImages || []) };
        } else {
          out = await runTool(call.name, call.input, ctx, agent);
        }
        if (out?.error) isError = true;
      } catch (e) {
        if (e.status === 499) throw e;
        out = { error: e.message };
        isError = true;
      }
      ctx.emit('tool_result', { agent, tool: call.name, ok: !isError, preview: out?.__content ? '[imagen]' : JSON.stringify(out).slice(0, 400) });
      results.push({ type: 'tool_result', tool_use_id: call.id, content: toolResultContent(out), ...(isError ? { is_error: true } : {}) });
    }
    messages.push({ role: 'user', content: results });
  }
  return 'Límite de pasos alcanzado; el trabajo puede estar incompleto.';
}

async function runSpecialist(agent, task, ctx, usage, referenceImages = []) {
  if (!AGENTS[agent] || AGENTS[agent].director) throw new HttpError(400, `Agente desconocido: ${agent}`);
  const p = providers();
  if (agent === 'math' && ctx.noMath) return 'No disponible: la matemática, el RTP y las apuestas de este juego las controla el proveedor. Solo se pueden cambiar diseño, imágenes y sonidos.';
  if (agent === 'artist' && !p.venice) return 'No disponible: falta VENICE_API_KEY en el servidor.';
  if (agent === 'sound' && !p.elevenlabs) return 'No disponible: falta ELEVENLABS_API_KEY en el servidor.';
  ctx.emit('agent_start', { agent, title: AGENTS[agent].title, task });
  const scope = EDIT_SCOPES[agent].join(', ');
  const { blocks, used } = imageBlocks(referenceImages);
  const firstText = `${task}\n\n(Rutas que puedes editar: ${scope})${used.length ? REF_NOTE(used) : ''}`;
  const content = blocks.length ? [...blocks, { type: 'text', text: firstText }] : firstText;
  const text = await agentLoop(agent, [{ role: 'user', content }], ctx, usage);
  ctx.emit('agent_done', { agent, summary: text });
  return text;
}

/**
 * Inicia (o continúa) una conversación con los agentes. Devuelve el runId de inmediato;
 * el progreso llega por eventos (SSE /api/admin/agents/runs/:id/events).
 * `agent` permite hablar directo con un especialista sin pasar por el director.
 */
export function startRun({ gameId, prompt, runId = null, agent = 'director', actor = 'admin', images = [], noMath = false }) {
  if (!providers().anthropic) throw new HttpError(503, 'Falta ANTHROPIC_API_KEY en las variables del servidor');
  if (!prompt?.trim()) throw new HttpError(400, 'Escribe un pedido para los agentes');
  if (!AGENTS[agent]) throw new HttpError(400, `Agente desconocido: ${agent}`);
  if (noMath && agent === 'math') throw new HttpError(403, 'La matemática de este juego la controla el proveedor');
  const game = getGame(gameId);
  let messages = [];
  if (runId) {
    const r = one('SELECT * FROM agent_runs WHERE id = ?', runId);
    if (!r) throw new HttpError(404, 'Conversación no encontrada');
    if (active.has(runId)) throw new HttpError(409, 'Los agentes siguen trabajando en esta conversación');
    messages = JSON.parse(r.messages || '[]');
    run("UPDATE agent_runs SET status = 'running', finished_at = NULL WHERE id = ?", runId);
  } else {
    runId = `run_${randomBytes(9).toString('base64url')}`;
    run("INSERT INTO agent_runs (id, game_id, prompt, status, messages) VALUES (?, ?, ?, 'running', '[]')", runId, gameId, prompt);
  }
  const state = { cancelled: false };
  active.set(runId, state);
  const ctx = { runId, gameId, engine: game.engine, actor, noMath, state, emit: (type, data) => persist(runId, type, data) };
  const usage = {};
  if (!Array.isArray(images)) images = [];
  if (images.length > MAX_REFS) throw new HttpError(400, `Máximo ${MAX_REFS} imágenes por mensaje`);
  const { blocks, used } = imageBlocks(images);
  messages.push({ role: 'user', content: blocks.length ? [...blocks, { type: 'text', text: prompt + REF_NOTE(used) }] : prompt });
  ctx.emit('user', { text: prompt, agent, images: used.map((a) => ({ id: a.id, url: a.url })) });

  (async () => {
    let status = 'done', summary = '';
    try {
      summary = agent === 'director'
        ? await agentLoop('director', messages, ctx, usage)
        : await agentLoop(agent, messages, ctx, usage);
    } catch (e) {
      status = e.status === 499 ? 'cancelled' : 'error';
      summary = e.message;
      ctx.emit('error', { message: e.message });
      // Deja la conversación en un estado válido para poder continuarla.
      const last = messages[messages.length - 1];
      if (last?.role === 'assistant' && last.content.some?.((b) => b.type === 'tool_use')) messages.pop();
      if (messages[messages.length - 1]?.role === 'user') messages.push({ role: 'assistant', content: `(Interrumpido: ${e.message})` });
    } finally {
      active.delete(runId);
      const prev = one('SELECT usage FROM agent_runs WHERE id = ?', runId);
      const total = prev?.usage ? JSON.parse(prev.usage) : {};
      addUsage(total, usage);
      run('UPDATE agent_runs SET status = ?, summary = ?, usage = ?, messages = ?, finished_at = datetime(\'now\') WHERE id = ?',
        status, summary.slice(0, 4000), JSON.stringify(total), JSON.stringify(forStorage(messages)), runId);
      ctx.emit('done', { status, summary, usage: total });
    }
  })();

  return { runId };
}
